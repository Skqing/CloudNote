# wujb —— node.js and mongodb blog website

  wujb是利用node.js和mongodb搭建的轻博客站点，这里是此站点的源文件

##项目演示网址：http://www.wujb.net

  本项目是基于node.js框架rrestjs开发构成的

##rrestjs框架：http://www.rrestjs.com
 
  rrestjs手把手教程： http://snoopyxdy.blog.163.com/blog/static/60117440201211743031517/

##安装方法：

  目前没有对windows环境下做任何测试和支持，请使用linux系统

  1、请先安装node.js的6.X以上版本
  
  2、npm install rrestjs

  3、从github上打包wujb源码下载  

  4、安装mongodb2.0以上数据库

  5、修改config文件夹下的配置文件，进行数据库连接

##架构及介绍：http://snoopyxdy.blog.163.com/blog/static/60117440201261844125973/

##意见建议：http://snoopyxdy.blog.163.com/blog/static/60117440201261984421292/

##联系方式

  email: snoopyxdy@163.com

  QQ: 53822985
